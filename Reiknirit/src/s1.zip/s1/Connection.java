package s1;

public class Connection
{
    int p, q;
    
    public Connection(int p, int q) 
    { this.p = p; this.q = q; }

    public int p() { return this.p; }
    public int q() { return this.q; }
	    
}